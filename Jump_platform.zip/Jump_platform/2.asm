format PE GUI 4.0
entry start

include 'win32a.inc'

; --- Структуры и Данные ---
section '.data' data readable writeable
    _class      db 'VerticalMarioClass',0
    _title      db 'FASM Vertical Mario: Space to Jump!',0
    
    posX        dd 220
    posY        dd 100
    velY        dd 0
    isJumping   db 1        ; Начинаем в падении
    
    GRAVITY      = 1
    JUMP_FORCE   = -15
    PLAYER_SIZE  = 30
    SCROLL_SPEED = 3        ; Скорость движения мира вниз

    struct PLATFORM
        x dd ?
        y dd ?
        w dd ?
        h dd ?
    ends

    platforms PLATFORM 150, 300, 150, 20
              PLATFORM 300, 180, 150, 20
              PLATFORM 100, 60,  150, 20
              PLATFORM 250, -60, 150, 20
    PLAT_COUNT = 4

    wc          WNDCLASS
    msg         MSG
    seed        dd 0xACE1   ; Для рандома

; --- Код ---
section '.code' code readable executable
start:
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.lpszClassName], _class
    mov     [wc.hbrBackground], COLOR_WINDOW + 1
    invoke  RegisterClass, wc
    
    invoke  CreateWindowEx, 0, _class, _title, WS_VISIBLE + WS_SYSMENU,\
            CW_USEDEFAULT, CW_USEDEFAULT, 500, 450, NULL, NULL, [wc.hInstance], NULL
    
    invoke  SetTimer, eax, 1, 16, NULL

msg_loop:
    invoke  GetMessage, msg, NULL, 0, 0
    or      eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    push    ebx esi edi ebp
    
    mov     eax, [wmsg]
    cmp     eax, WM_TIMER
    je      .ontimer
    cmp     eax, WM_PAINT
    je      .onpaint
    cmp     eax, WM_ERASEBKGND
    je      .onerase
    cmp     eax, WM_DESTROY
    je      .wmdestroy
    
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp     .finish

.onerase:
    mov     eax, 1
    jmp     .finish

.ontimer:
    ; 1. Управление (Горизонталь)
    invoke  GetAsyncKeyState, VK_LEFT
    test    eax, 0x8000
    jz      .not_l
    sub     [posX], 7
.not_l:
    invoke  GetAsyncKeyState, VK_RIGHT
    test    eax, 0x8000
    jz      .not_r
    add     [posX], 7
.not_r:
    
    ; 2. Прыжок (Только если стоим на платформе)
    invoke  GetAsyncKeyState, VK_SPACE
    test    eax, 0x8000
    jz      .apply_gravity
    cmp     [isJumping], 0
    jne     .apply_gravity
    mov     [velY], JUMP_FORCE
    mov     [isJumping], 1

.apply_gravity:
    mov     eax, GRAVITY
    add     [velY], eax
    mov     eax, [velY]
    add     [posY], eax

    ; По умолчанию считаем, что мы падаем
    mov     [isJumping], 1

    ; 3. Обновление платформ и Коллизии
    mov     ecx, PLAT_COUNT
    mov     esi, platforms
.plat_loop:
    push    ecx
    
    ; Платформа едет вниз
    mov     eax, SCROLL_SPEED
    add     [esi + PLATFORM.y], eax

    ; Если ушла вниз — генерируем новую сверху
    cmp     [esi + PLATFORM.y], 420
    jl      .collision
    mov     [esi + PLATFORM.y], -40
    ; Рандом X (LCG)
    mov     eax, [seed]
    imul    eax, 1103515245
    add     eax, 12345
    mov     [seed], eax
    and     eax, 300
    add     eax, 20
    mov     [esi + PLATFORM.x], eax

.collision:
    ; Коллизия только при падении (velY >= 0)
    cmp     [velY], 0
    jl      .next_p
    
    ; Проверка X
    mov     eax, [posX]
    add     eax, PLAYER_SIZE
    cmp     eax, [esi + PLATFORM.x]
    jl      .next_p
    mov     eax, [posX]
    mov     ebx, [esi + PLATFORM.x]
    add     ebx, [esi + PLATFORM.w]
    cmp     eax, ebx
    jg      .next_p
    
    ; Проверка Y (наступил сверху)
    mov     eax, [posY]
    add     eax, PLAYER_SIZE
    cmp     eax, [esi + PLATFORM.y]
    jl      .next_p
    sub     eax, [velY] ; проверка "до прыжка"
    cmp     eax, [esi + PLATFORM.y]
    jg      .next_p

    ; ПРИЗЕМЛЕНИЕ:
    mov     eax, [esi + PLATFORM.y]
    sub     eax, PLAYER_SIZE
    add     eax, SCROLL_SPEED ; Синхронизация с движением платформы
    mov     [posY], eax
    mov     [velY], 0
    mov     [isJumping], 0

.next_p:
    pop     ecx
    add     esi, sizeof.PLATFORM
    dec     ecx
    jnz     .plat_loop

    ; 4. Проверка смерти (улетел за нижний край)
    cmp     [posY], 450
    jl      .redraw
    mov     [posY], 0 ; Респаун
    mov     [posX], 220
    mov     [velY], 0

.redraw:
    invoke  InvalidateRect, [hwnd], NULL, FALSE
    jmp     .finish

.onpaint:
    locals
        ps PAINTSTRUCT
        hdcM dd ?
        hbmM dd ?
        hOld dd ?
        rc RECT
    endl
    lea eax, [ps]
    invoke BeginPaint, [hwnd], eax
    mov edi, eax 
    lea ebx, [rc]
    invoke GetClientRect, [hwnd], ebx
    
    invoke CreateCompatibleDC, edi
    mov [hdcM], eax
    invoke CreateCompatibleBitmap, edi, [rc.right], [rc.bottom]
    mov [hbmM], eax
    invoke SelectObject, [hdcM], [hbmM]
    mov [hOld], eax
    
    ; Фон (Небо)
    invoke CreateSolidBrush, 0x00FFCC66
    lea edx, [rc]
    invoke FillRect, [hdcM], edx, eax
    invoke DeleteObject, eax

    ; Рисуем платформы
    invoke CreateSolidBrush, 0x00224488
    invoke SelectObject, [hdcM], eax
    push eax
    mov ecx, PLAT_COUNT
    mov esi, platforms
.draw_p:
    push ecx esi
    mov eax, [esi+PLATFORM.x]
    mov ebx, [esi+PLATFORM.y]
    mov ecx, eax
    add ecx, [esi+PLATFORM.w]
    mov edx, ebx
    add edx, [esi+PLATFORM.h]
    invoke Rectangle, [hdcM], eax, ebx, ecx, edx
    pop esi ecx
    add esi, sizeof.PLATFORM
    dec ecx
    jnz .draw_p
    pop eax
    invoke DeleteObject, eax

    ; Рисуем Марио
    invoke CreateSolidBrush, 0x000000FF
    invoke SelectObject, [hdcM], eax
    push eax
    mov eax, [posX]
    mov ebx, [posY]
    mov ecx, eax
    add ecx, PLAYER_SIZE
    mov edx, ebx
    add edx, PLAYER_SIZE
    invoke Rectangle, [hdcM], eax, ebx, ecx, edx
    pop eax
    invoke DeleteObject, eax

    invoke BitBlt, edi, 0, 0, [rc.right], [rc.bottom], [hdcM], 0, 0, SRCCOPY
    invoke SelectObject, [hdcM], [hOld]
    invoke DeleteObject, [hbmM]
    invoke DeleteDC, [hdcM]
    lea eax, [ps]
    invoke EndPaint, [hwnd], eax
    jmp .finish

.wmdestroy:
    invoke PostQuitMessage, 0
.finish:
    pop ebp edi esi ebx
    ret
endp

section '.idata' import data readable
    library kernel32,'KERNEL32.DLL',user32,'USER32.DLL',gdi32,'GDI32.DLL'
    include 'api/kernel32.inc'
    include 'api/user32.inc'
    include 'api/gdi32.inc'
