format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    _class      db 'VerticalMarioClass',0
    _title      db 'FASM Vertical Mario: Space to Start!',0
    _msg_lost   db 'GAME OVER!',13,10,'Your score: %d',0
    _msg_cap    db 'Restarting...',0
    _scoreText  db 'Score: %d',0
    
    posX        dd 220
    posY        dd 330
    velY        dd 0
    score       dd 0
    isJumping   db 0
    gameStarted db 0
    
    GRAVITY      = 1
    JUMP_FORCE   = -16
    PLAYER_SIZE  = 30
    SCROLL_SPEED = 3
    PLAT_W       = 150
    PLAT_H       = 20

    struct PLATFORM
        x dd ?
        y dd ?
        w dd ?
        h dd ?
    ends

    platforms PLATFORM 175, 360, PLAT_W, PLAT_H
              PLATFORM 300, 200, PLAT_W, PLAT_H
              PLATFORM 100, 100, PLAT_W, PLAT_H
              PLATFORM 250, 0,   PLAT_W, PLAT_H
    PLAT_COUNT = 4

    wc          WNDCLASS
    msg         MSG
    seed        dd 0xACE1
    scoreBuf    db 32 dup(0)
    msgBuf      db 64 dup(0)

section '.code' code readable executable
start:
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.lpszClassName], _class
    mov     [wc.hbrBackground], COLOR_WINDOW + 1
    invoke  RegisterClass, wc
    
    invoke  CreateWindowEx, 0, _class, _title, WS_VISIBLE + WS_SYSMENU,\
            CW_USEDEFAULT, CW_USEDEFAULT, 500, 450, NULL, NULL, [wc.hInstance], NULL
    
    invoke  SetTimer, eax, 1, 16, NULL

msg_loop:
    invoke  GetMessage, msg, NULL, 0, 0
    or      eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    push    ebx esi edi ebp
    
    mov     eax, [wmsg]
    cmp     eax, WM_TIMER
    je      .ontimer
    cmp     eax, WM_PAINT
    je      .onpaint
    cmp     eax, WM_ERASEBKGND
    je      .onerase
    cmp     eax, WM_DESTROY
    je      .wmdestroy
    
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp     .finish

.onerase:
    mov     eax, 1
    jmp     .finish

.ontimer:
    cmp     [gameStarted], 0
    je      .alive
    cmp     [posY], 410
    jl      .alive
    
    invoke  KillTimer, [hwnd], 1
    cinvoke wsprintf, msgBuf, _msg_lost, [score]
    invoke  MessageBox, [hwnd], msgBuf, _msg_cap, MB_OK + MB_ICONINFORMATION
    ; Сброс
    mov     [gameStarted], 0
    mov     [score], 0
    mov     [posX], 220
    mov     [posY], 330
    mov     [velY], 0
    mov     [isJumping], 0
    mov     [platforms.x], 175
    mov     [platforms.y], 360
    mov     [platforms.y+16], 200
    mov     [platforms.y+32], 100
    mov     [platforms.y+48], 0
    invoke  SetTimer, [hwnd], 1, 16, NULL
    jmp     .redraw

.alive:
    invoke  GetAsyncKeyState, VK_LEFT
    test    eax, 0x8000
    jz      .not_l
    sub     [posX], 7
.not_l:
    invoke  GetAsyncKeyState, VK_RIGHT
    test    eax, 0x8000
    jz      .not_r
    add     [posX], 7
.not_r:
    
    invoke  GetAsyncKeyState, VK_SPACE
    test    eax, 0x8000
    jz      .apply_gravity
    cmp     [isJumping], 0
    jne     .apply_gravity
    mov     [gameStarted], 1
    mov     [velY], JUMP_FORCE
    mov     [isJumping], 1

.apply_gravity:
    mov     eax, GRAVITY
    add     [velY], eax
    mov     eax, [velY]
    add     [posY], eax
    mov     [isJumping], 1

    mov     ecx, PLAT_COUNT
    mov     esi, platforms
.plat_loop:
    push    ecx
    cmp     [gameStarted], 0
    je      .collision
    mov     eax, SCROLL_SPEED
    add     [esi + PLATFORM.y], eax

    cmp     [esi + PLATFORM.y], 420
    jl      .collision
    ; Платформа пройдена - очки!
    inc     [score]
    mov     [esi + PLATFORM.y], -40
    mov     eax, [seed]
    imul    eax, 1103515245
    add     eax, 12345
    mov     [seed], eax
    and     eax, 300
    add     eax, 20
    mov     [esi + PLATFORM.x], eax

.collision:
    cmp     [velY], 0
    jl      .next_p
    mov     eax, [posX]
    add     eax, PLAYER_SIZE
    cmp     eax, [esi + PLATFORM.x]
    jl      .next_p
    mov     eax, [posX]
    mov     ebx, [esi + PLATFORM.x]
    add     ebx, [esi + PLATFORM.w]
    cmp     eax, ebx
    jg      .next_p
    mov     eax, [posY]
    add     eax, PLAYER_SIZE
    cmp     eax, [esi + PLATFORM.y]
    jl      .next_p
    sub     eax, [velY]
    cmp     eax, [esi + PLATFORM.y]
    jg      .next_p

    mov     eax, [esi + PLATFORM.y]
    sub     eax, PLAYER_SIZE
    cmp     [gameStarted], 1
    jne     .stay_still
    add     eax, SCROLL_SPEED
.stay_still:
    mov     [posY], eax
    mov     [velY], 0
    mov     [isJumping], 0

.next_p:
    pop     ecx
    add     esi, sizeof.PLATFORM
    dec     ecx
    jnz     .plat_loop

.redraw:
    invoke  InvalidateRect, [hwnd], NULL, FALSE
    jmp     .finish

.onpaint:
    locals
        ps PAINTSTRUCT
        hdcM dd ?
        hbmM dd ?
        hOld dd ?
        rc RECT
    endl
    lea eax, [ps]
    invoke BeginPaint, [hwnd], eax
    mov edi, eax 
    lea ebx, [rc]
    invoke GetClientRect, [hwnd], ebx
    invoke CreateCompatibleDC, edi
    mov [hdcM], eax
    invoke CreateCompatibleBitmap, edi, [rc.right], [rc.bottom]
    mov [hbmM], eax
    invoke SelectObject, [hdcM], [hbmM]
    mov [hOld], eax
    
    invoke CreateSolidBrush, 0x00FFCC66
    lea edx, [rc]
    invoke FillRect, [hdcM], edx, eax
    invoke DeleteObject, eax

    invoke CreateSolidBrush, 0x00224488
    invoke SelectObject, [hdcM], eax
    push eax
    mov ecx, PLAT_COUNT
    mov esi, platforms
.draw_p:
    push    ecx esi
    mov     eax, [esi+PLATFORM.x]
    mov     ebx, [esi+PLATFORM.y]
    mov     ecx, eax
    add     ecx, [esi+PLATFORM.w]
    mov     edx, ebx
    add     edx, [esi+PLATFORM.h]
    invoke  Rectangle, [hdcM], eax, ebx, ecx, edx
    pop     esi ecx
    add     esi, sizeof.PLATFORM
    dec     ecx
    jnz     .draw_p
    pop     eax
    invoke  DeleteObject, eax

    invoke CreateSolidBrush, 0x000000FF
    invoke SelectObject, [hdcM], eax
    push eax
    mov eax, [posX]
    mov ebx, [posY]
    mov ecx, eax
    add ecx, PLAYER_SIZE
    mov edx, ebx
    add edx, PLAYER_SIZE
    invoke Rectangle, [hdcM], eax, ebx, ecx, edx
    pop eax
    invoke DeleteObject, eax

    ; --- Отрисовка счета ---
    invoke  SetBkMode, [hdcM], TRANSPARENT
    invoke  SetTextColor, [hdcM], 0x00FFFFFF ; Белый
    cinvoke wsprintf, scoreBuf, _scoreText, [score]
    invoke  TextOut, [hdcM], 10, 10, scoreBuf, eax

    invoke BitBlt, edi, 0, 0, [rc.right], [rc.bottom], [hdcM], 0, 0, SRCCOPY
    invoke SelectObject, [hdcM], [hOld]
    invoke DeleteObject, [hbmM]
    invoke DeleteDC, [hdcM]
    lea eax, [ps]
    invoke EndPaint, [hwnd], eax
    jmp .finish

.wmdestroy:
    invoke PostQuitMessage, 0
    xor     eax, eax
.finish:
    pop ebp edi esi ebx
    ret
endp

section '.idata' import data readable
    library kernel32,'KERNEL32.DLL',user32,'USER32.DLL',gdi32,'GDI32.DLL'
    import kernel32, ExitProcess,'ExitProcess', GetModuleHandle,'GetModuleHandleA'
    import user32, RegisterClass,'RegisterClassA', CreateWindowEx,'CreateWindowExA',\
                   DefWindowProc,'DefWindowProcA', GetMessage,'GetMessageA',\
                   TranslateMessage,'TranslateMessage', DispatchMessage,'DispatchMessageA',\
                   PostQuitMessage,'PostQuitMessage', SetTimer,'SetTimer', KillTimer,'KillTimer',\
                   InvalidateRect,'InvalidateRect', BeginPaint,'BeginPaint', EndPaint,'EndPaint',\
                   GetClientRect,'GetClientRect', GetAsyncKeyState,'GetAsyncKeyState', FillRect,'FillRect', \
                   MessageBox, 'MessageBoxA', wsprintf, 'wsprintfA'
    import gdi32,  Rectangle,'Rectangle', CreateSolidBrush,'CreateSolidBrush', \
                   SelectObject,'SelectObject', DeleteObject,'DeleteObject', BitBlt,'BitBlt', \
                   CreateCompatibleDC,'CreateCompatibleDC', CreateCompatibleBitmap,'CreateCompatibleBitmap', \
                   DeleteDC,'DeleteDC', TextOut, 'TextOutA', SetBkMode, 'SetBkMode', SetTextColor, 'SetTextColor'
