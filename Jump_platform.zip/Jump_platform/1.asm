format PE GUI 4.0
entry start

include 'win32a.inc'

; --- Данные ---
section '.data' data readable writeable
    _class      db 'MarioClass',0
    _title      db 'FASM Mario: Arrows=Move, Space=Jump',0
    
    posX        dd 100
    posY        dd 150
    velY        dd 0
    isJumping   db 0
    
    GRAVITY     = 2
    JUMP_FORCE  = -22
    PLAYER_SIZE = 30
    
    struct PLATFORM
        x dd ?
        y dd ?
        w dd ?
        h dd ?
    ends

    platforms PLATFORM 0, 320, 2000, 50   ; Пол
              PLATFORM 250, 230, 150, 20  ; Платформа 1
              PLATFORM 500, 160, 150, 20  ; Платформа 2
    PLAT_COUNT = 3

    wc          WNDCLASS
    msg         MSG

; --- Код ---
section '.code' code readable executable
start:
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.lpszClassName], _class
    mov     [wc.hbrBackground], COLOR_WINDOW + 1
    invoke  RegisterClass, wc
    
    invoke  CreateWindowEx, 0, _class, _title, WS_VISIBLE + WS_SYSMENU,\
            CW_USEDEFAULT, CW_USEDEFAULT, 640, 440, NULL, NULL, [wc.hInstance], NULL
    
    invoke  SetTimer, eax, 1, 16, NULL

msg_loop:
    invoke  GetMessage, msg, NULL, 0, 0
    or      eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    push    ebx esi edi ebp
    
    mov     eax, [wmsg]
    cmp     eax, WM_TIMER
    je      .ontimer
    cmp     eax, WM_PAINT
    je      .onpaint
    cmp     eax, WM_ERASEBKGND
    je      .onerase
    cmp     eax, WM_DESTROY
    je      .wmdestroy
    
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp     .finish

.onerase:
    mov     eax, 1
    jmp     .finish

.ontimer:
    ; Движение влево
    invoke  GetAsyncKeyState, VK_LEFT
    test    eax, 0x8000
    jz      .not_left
    sub     [posX], 7
.not_left:
    ; Движение вправо
    invoke  GetAsyncKeyState, VK_RIGHT
    test    eax, 0x8000
    jz      .not_right
    add     [posX], 7
.not_right:
    
    ; Физика прыжка
    mov     eax, GRAVITY
    add     [velY], eax
    mov     eax, [velY]
    add     [posY], eax

    invoke  GetAsyncKeyState, VK_SPACE
    test    eax, 0x8000
    jz      .physics
    cmp     [isJumping], 0
    jne     .physics
    mov     [velY], JUMP_FORCE
    mov     [isJumping], 1

.physics:
    mov     ecx, PLAT_COUNT
    mov     esi, platforms
.coll_loop:
    push    ecx
    ; Проверка X
    mov     eax, [posX]
    add     eax, PLAYER_SIZE
    cmp     eax, [esi + PLATFORM.x]
    jl      .next_p
    mov     eax, [posX]
    mov     ebx, [esi + PLATFORM.x]
    add     ebx, [esi + PLATFORM.w]
    cmp     eax, ebx
    jg      .next_p
    
    ; Проверка Y (приземление)
    mov     eax, [posY]
    add     eax, PLAYER_SIZE
    cmp     eax, [esi + PLATFORM.y]
    jl      .next_p
    sub     eax, [velY]
    cmp     eax, [esi + PLATFORM.y]
    jg      .next_p

    ; Встаем на платформу
    mov     eax, [esi + PLATFORM.y]
    sub     eax, PLAYER_SIZE
    mov     [posY], eax
    mov     [velY], 0
    mov     [isJumping], 0
.next_p:
    pop     ecx
    add     esi, sizeof.PLATFORM
    dec     ecx
    jnz     .coll_loop

    ; Если упал слишком низко - рестарт
    cmp     [posY], 500
    jl      .redraw
    mov     [posX], 100
    mov     [posY], 150
    mov     [velY], 0

.redraw:
    invoke  InvalidateRect, [hwnd], NULL, FALSE
    jmp     .finish

.onpaint:
    locals
        ps    PAINTSTRUCT
        hdcM  dd ?
        hbmM  dd ?
        hOld  dd ?
        rc    RECT
    endl
    lea     eax, [ps]
    invoke  BeginPaint, [hwnd], eax
    mov     edi, eax 
    
    lea     ebx, [rc]
    invoke  GetClientRect, [hwnd], ebx
    
    invoke  CreateCompatibleDC, edi
    mov     [hdcM], eax
    invoke  CreateCompatibleBitmap, edi, [rc.right], [rc.bottom]
    mov     [hbmM], eax
    invoke  SelectObject, [hdcM], [hbmM]
    mov     [hOld], eax
    
    ; Небо
    invoke  CreateSolidBrush, 0x00FFCC66
    lea     edx, [rc]
    invoke  FillRect, [hdcM], edx, eax
    invoke  DeleteObject, eax

    ; Отрисовка платформ
    invoke  CreateSolidBrush, 0x00224488
    invoke  SelectObject, [hdcM], eax
    push    eax
    mov     ecx, PLAT_COUNT
    mov     esi, platforms
.draw_loop:
    push    ecx esi
    mov     eax, [esi + PLATFORM.x]
    mov     ebx, [esi + PLATFORM.y]
    mov     ecx, eax
    add     ecx, [esi + PLATFORM.w]
    mov     edx, ebx
    add     edx, [esi + PLATFORM.h]
    invoke  Rectangle, [hdcM], eax, ebx, ecx, edx
    pop     esi ecx
    add     esi, sizeof.PLATFORM
    dec     ecx
    jnz     .draw_loop
    pop     eax
    invoke  DeleteObject, eax

    ; Отрисовка Марио
    invoke  CreateSolidBrush, 0x000000FF
    invoke  SelectObject, [hdcM], eax
    push    eax
    mov     eax, [posX]
    mov     ebx, [posY]
    mov     ecx, eax
    add     ecx, PLAYER_SIZE
    mov     edx, ebx
    add     edx, PLAYER_SIZE
    invoke  Rectangle, [hdcM], eax, ebx, ecx, edx
    pop     eax
    invoke  DeleteObject, eax

    ; Вывод на экран
    invoke  BitBlt, edi, 0, 0, [rc.right], [rc.bottom], [hdcM], 0, 0, SRCCOPY
    
    invoke  SelectObject, [hdcM], [hOld]
    invoke  DeleteObject, [hbmM]
    invoke  DeleteDC, [hdcM]
    lea     eax, [ps]
    invoke  EndPaint, [hwnd], eax
    jmp     .finish

.wmdestroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax

.finish:
    pop     ebp edi esi ebx
    ret
endp

section '.idata' import data readable
    library kernel32,'KERNEL32.DLL',user32,'USER32.DLL',gdi32,'GDI32.DLL'
    include 'api/kernel32.inc'
    include 'api/user32.inc'
    include 'api/gdi32.inc'
