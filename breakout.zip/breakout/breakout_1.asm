format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    _class      db 'ArkanoidClass',0
    _title      db 'FASM Arkanoid: Paddle Edition',0
    
    ; Мяч
    ballX       dd 100
    ballY       dd 100
    ballDX      dd 4
    ballDY      dd 4
    ballSize    dd 15

    ; Ракетка
    padX        dd 200
    padY        dd 250
    padW        dd 80
    padH        dd 12
    padSpeed    dd 15

    msg         MSG
    wc          WNDCLASS
    rect        RECT

section '.code' code readable executable
start:
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.lpszClassName], _class
    mov     [wc.hbrBackground], COLOR_WINDOW + 1
    invoke  RegisterClass, wc
    
    invoke  CreateWindowEx, 0, _class, _title, WS_VISIBLE + WS_SYSMENU,\
            CW_USEDEFAULT, CW_USEDEFAULT, 480, 320, NULL, NULL, [wc.hInstance], NULL
    
    invoke  SetTimer, eax, 1, 16, NULL

msg_loop:
    invoke  GetMessage, msg, NULL, 0, 0
    or      eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    push    ebx esi edi
    
    cmp     [wmsg], WM_KEYDOWN
    je      .onkey
    cmp     [wmsg], WM_TIMER
    je      .ontimer
    cmp     [wmsg], WM_PAINT
    je      .onpaint
    cmp     [wmsg], WM_DESTROY
    je      .wmdestroy
    
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp     .finish

.onkey:
    mov     eax, [wparam]
    cmp     eax, VK_LEFT
    je      .moveLeft
    cmp     eax, VK_RIGHT
    je      .moveRight
    jmp     .finish
.moveLeft:
    sub     [padX], 20
    jmp     .finish
.moveRight:
    add     [padX], 20
    jmp     .finish

.ontimer:
    ; Движение мяча
    mov     eax, [ballDX]
    add     [ballX], eax
    mov     eax, [ballDY]
    add     [ballY], eax
    
    invoke  GetClientRect, [hwnd], rect
    
    ; Стенки
    cmp     [ballX], 0
    jle     .revX
    mov     eax, [rect.right]
    sub     eax, [ballSize]
    cmp     [ballX], eax
    jge     .revX
    
    cmp     [ballY], 0
    jle     .revY
    
    ; Проверка падения (дно)
    mov     eax, [rect.bottom]
    cmp     [ballY], eax
    jge     .gameOver

    ; СТОЛКНОВЕНИЕ С РАКЕТКОЙ
    mov     eax, [ballY]
    add     eax, [ballSize]
    cmp     eax, [padY]
    jl      .redraw          ; Мяч выше ракетки
    
    mov     ebx, [padY]
    add     ebx, [padH]
    cmp     eax, ebx
    jg      .redraw          ; Мяч ниже ракетки
    
    mov     eax, [ballX]
    cmp     eax, [padX]
    jl      .redraw          ; Левее
    mov     ebx, [padX]
    add     ebx, [padW]
    cmp     eax, ebx
    jg      .redraw          ; Правее
    
    neg     [ballDY]         ; Отскок от ракетки
    jmp     .redraw

.revX:
    neg     [ballDX]
    jmp     .redraw
.revY:
    neg     [ballDY]
    jmp     .redraw

.gameOver:
    mov     [ballX], 100
    mov     [ballY], 100
    jmp     .redraw

.redraw:
    invoke  InvalidateRect, [hwnd], NULL, TRUE
    jmp     .finish

.onpaint:
    locals
        ps PAINTSTRUCT
    endl
    lea     eax, [ps]
    invoke  BeginPaint, [hwnd], eax
    mov     ebx, eax
    
    ; Рисуем мяч (Синий)
    invoke  CreateSolidBrush, 0x00FF9000 
    invoke  SelectObject, ebx, eax
    push    eax
    mov     esi, [ballX]
    mov     edi, [ballY]
    mov     ecx, esi
    mov     edx, edi
    add     ecx, [ballSize]
    add     edx, [ballSize]
    invoke  Ellipse, ebx, esi, edi, ecx, edx
    pop     eax
    invoke  SelectObject, ebx, eax
    invoke  DeleteObject, eax

    ; Рисуем ракетку (Черная)
    invoke  CreateSolidBrush, 0x00000000
    invoke  SelectObject, ebx, eax
    push    eax
    mov     esi, [padX]
    mov     edi, [padY]
    mov     ecx, esi
    mov     edx, edi
    add     ecx, [padW]
    add     edx, [padH]
    invoke  Rectangle, ebx, esi, edi, ecx, edx
    pop     eax
    invoke  SelectObject, ebx, eax
    invoke  DeleteObject, eax
    
    lea     eax, [ps]
    invoke  EndPaint, [hwnd], eax
    jmp     .finish

.wmdestroy:
    invoke  KillTimer, [hwnd], 1
    invoke  PostQuitMessage, 0
    xor     eax, eax

.finish:
    pop     edi esi ebx
    ret
endp

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL',\
            user32,   'USER32.DLL',\
            gdi32,    'GDI32.DLL'

    import kernel32, ExitProcess, 'ExitProcess', GetModuleHandle, 'GetModuleHandleA'
    import user32, RegisterClass, 'RegisterClassA', CreateWindowEx, 'CreateWindowExA',\
                   DefWindowProc, 'DefWindowProcA', GetMessage, 'GetMessageA',\
                   TranslateMessage, 'TranslateMessage', DispatchMessage, 'DispatchMessageA',\
                   PostQuitMessage, 'PostQuitMessage', SetTimer, 'SetTimer', KillTimer, 'KillTimer',\
                   InvalidateRect, 'InvalidateRect', BeginPaint, 'BeginPaint', EndPaint, 'EndPaint',\
                   GetClientRect, 'GetClientRect'
    import gdi32,  Ellipse, 'Ellipse', Rectangle, 'Rectangle', CreateSolidBrush, 'CreateSolidBrush', \
                   SelectObject, 'SelectObject', DeleteObject, 'DeleteObject'
