format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    _class      db 'ArkanoidClass',0
    _title      db 'FASM Arkanoid EXE',0
    
    ; Переменные игры
    ballX       dd 100
    ballY       dd 100
    ballDX      dd 4
    ballDY      dd 4
    ballSize    dd 15

    msg         MSG
    wc          WNDCLASS
    rect        RECT

section '.code' code readable executable
start:
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.lpszClassName], _class
    mov     [wc.hbrBackground], COLOR_WINDOW + 1
    invoke  RegisterClass, wc
    
    invoke  CreateWindowEx, 0, _class, _title, WS_VISIBLE + WS_OVERLAPPEDWINDOW,\
            CW_USEDEFAULT, CW_USEDEFAULT, 480, 320, NULL, NULL, [wc.hInstance], NULL
    
    ; Запускаем таймер (обновление каждые 16мс ~ 60 FPS)
    invoke  SetTimer, eax, 1, 16, NULL

msg_loop:
    invoke  GetMessage, msg, NULL, 0, 0
    or      eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    push    ebx esi edi
    
    cmp     [wmsg], WM_TIMER
    je      .ontimer
    cmp     [wmsg], WM_PAINT
    je      .onpaint
    cmp     [wmsg], WM_DESTROY
    je      .wmdestroy
    
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp     .finish

.ontimer:
    ; Движение шарика
    mov     eax, [ballDX]
    add     [ballX], eax
    mov     eax, [ballDY]
    add     [ballY], eax
    
    ; Проверка границ (упрощенно)
    invoke  GetClientRect, [hwnd], rect
    
    cmp     [ballX], 0
    jle     .revX
    mov     eax, [rect.right]
    sub     eax, [ballSize]
    cmp     [ballX], eax
    jge     .revX
    
    cmp     [ballY], 0
    jle     .revY
    mov     eax, [rect.bottom]
    sub     eax, [ballSize]
    cmp     [ballY], eax
    jge     .revY
    
    jmp     .redraw

.revX:
    neg     [ballDX]
    jmp     .redraw
.revY:
    neg     [ballDY]

.redraw:
    invoke  InvalidateRect, [hwnd], NULL, TRUE ; Перерисовать окно
    jmp     .finish

.onpaint:
    locals
        ps PAINTSTRUCT
    endl
    lea     eax, [ps]         ; Получаем адрес локальной переменной ps
    invoke  BeginPaint, [hwnd], eax
    mov     ebx, eax          ; hdc теперь в ebx
    
    ; Рисуем шарик
    invoke  CreateSolidBrush, 0x00FF9500 
    invoke  SelectObject, ebx, eax
    push    eax 
    
    mov     ecx, [ballX]
    mov     edx, [ballY]
    mov     esi, ecx
    mov     edi, edx
    add     esi, [ballSize]
    add     edi, [ballSize]
    invoke  Ellipse, ebx, ecx, edx, esi, edi
    
    pop     eax
    invoke  SelectObject, ebx, eax
    invoke  DeleteObject, eax
    
    lea     eax, [ps]         ; Снова берем адрес ps для завершения
    invoke  EndPaint, [hwnd], eax
    jmp     .finish

.wmdestroy:
    invoke  KillTimer, [hwnd], 1
    invoke  PostQuitMessage, 0
    xor     eax, eax

.finish:
    pop     edi esi ebx
    ret
endp

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL',\
            user32,   'USER32.DLL',\
            gdi32,    'GDI32.DLL'

    import kernel32, ExitProcess, 'ExitProcess', GetModuleHandle, 'GetModuleHandleA'
    import user32, RegisterClass, 'RegisterClassA', CreateWindowEx, 'CreateWindowExA',\
                   DefWindowProc, 'DefWindowProcA', GetMessage, 'GetMessageA',\
                   TranslateMessage, 'TranslateMessage', DispatchMessage, 'DispatchMessageA',\
                   PostQuitMessage, 'PostQuitMessage', SetTimer, 'SetTimer', KillTimer, 'KillTimer',\
                   InvalidateRect, 'InvalidateRect', BeginPaint, 'BeginPaint', EndPaint, 'EndPaint',\
                   GetClientRect, 'GetClientRect'
    import gdi32,  Ellipse, 'Ellipse', CreateSolidBrush, 'CreateSolidBrush', \
                   SelectObject, 'SelectObject', DeleteObject, 'DeleteObject'
