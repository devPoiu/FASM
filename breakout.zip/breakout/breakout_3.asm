format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    _class      db 'ArkanoidClass',0
    _title      db 'FASM Arkanoid: Bricks Edition',0
    
    ballX       dd 100
    ballY       dd 150
    ballDX      dd 4
    ballDY      dd 4
    ballSize    dd 15

    padX        dd 200
    padY        dd 250
    padW        dd 80
    padH        dd 12

    ; Настройки блоков
    BRICK_ROWS    = 3
    BRICK_COLS    = 6
    BRICK_WIDTH   = 70
    BRICK_HEIGHT  = 20
    BRICK_GAP     = 5
    ; Массив состояний: 1 - жив, 0 - разбит
    bricks      db BRICK_ROWS * BRICK_COLS dup(1)

    msg         MSG
    wc          WNDCLASS
    rect        RECT

section '.code' code readable executable
start:
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.lpszClassName], _class
    mov     [wc.hbrBackground], COLOR_WINDOW + 1
    invoke  RegisterClass, wc
    
    invoke  CreateWindowEx, 0, _class, _title, WS_VISIBLE + WS_SYSMENU,\
            CW_USEDEFAULT, CW_USEDEFAULT, 480, 320, NULL, NULL, [wc.hInstance], NULL
    
    invoke  SetTimer, eax, 1, 16, NULL

msg_loop:
    invoke  GetMessage, msg, NULL, 0, 0
    or      eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    push    ebx esi edi
    
    cmp     [wmsg], WM_KEYDOWN
    je      .onkey
    cmp     [wmsg], WM_TIMER
    je      .ontimer
    cmp     [wmsg], WM_PAINT
    je      .onpaint
    cmp     [wmsg], WM_DESTROY
    je      .wmdestroy
    
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp     .finish

.onkey:
    mov     eax, [wparam]
    cmp     eax, VK_LEFT
    je      .moveLeft
    cmp     eax, VK_RIGHT
    je      .moveRight
    jmp     .finish
.moveLeft:
    sub     [padX], 20
    jmp     .finish
.moveRight:
    add     [padX], 20
    jmp     .finish

.ontimer:
    mov     eax, [ballDX]
    add     [ballX], eax
    mov     eax, [ballDY]
    add     [ballY], eax
    
    invoke  GetClientRect, [hwnd], rect
    
    ; Стенки
    cmp     [ballX], 0
    jle     .revX
    mov     eax, [rect.right]
    sub     eax, [ballSize]
    cmp     [ballX], eax
    jge     .revX
    cmp     [ballY], 0
    jle     .revY
    
    mov     eax, [rect.bottom]
    cmp     [ballY], eax
    jge     .gameOver

    ; Коллизия с ракеткой
    mov     eax, [ballY]
    add     eax, [ballSize]
    cmp     eax, [padY]
    jl      .checkBricks
    mov     ebx, [padY]
    add     ebx, [padH]
    cmp     eax, ebx
    jg      .checkBricks
    mov     eax, [ballX]
    cmp     eax, [padX]
    jl      .checkBricks
    mov     ebx, [padX]
    add     ebx, [padW]
    cmp     eax, ebx
    jg      .checkBricks
    neg     [ballDY]

.checkBricks:
    ; Проверка столкновения с блоками
    xor     ecx, ecx ; индекс блока i
.brickLoop:
    cmp     [bricks + ecx], 0
    je      .nextBrick
    
    ; Вычисляем координаты блока i
    push    ecx
    xor     edx, edx
    mov     eax, ecx
    mov     ebx, BRICK_COLS
    div     ebx      ; eax = row, edx = col
    
    imul    edx, BRICK_WIDTH + BRICK_GAP
    add     edx, 20  ; X координата блока в edx
    imul    eax, BRICK_HEIGHT + BRICK_GAP
    add     eax, 20  ; Y координата блока в eax
    
    ; Простая проверка вхождения мяча в прямоугольник блока
    mov     esi, [ballX]
    cmp     esi, edx
    jl      .popNext
    add     edx, BRICK_WIDTH
    cmp     esi, edx
    jg      .popNext
    
    mov     edi, [ballY]
    cmp     edi, eax
    jl      .popNext
    add     eax, BRICK_HEIGHT
    cmp     edi, eax
    jg      .popNext
    
    ; Если попали:
    pop     ecx
    mov     [bricks + ecx], 0
    neg     [ballDY]
    jmp     .redraw

.popNext:
    pop     ecx
.nextBrick:
    inc     ecx
    cmp     ecx, BRICK_ROWS * BRICK_COLS
    jl      .brickLoop

.redraw:
    invoke  InvalidateRect, [hwnd], NULL, TRUE
    jmp     .finish

.revX:
    neg     [ballDX]
    jmp     .redraw
.revY:
    neg     [ballDY]
    jmp     .redraw

.gameOver:
    mov     [ballX], 100
    mov     [ballY], 150
    jmp     .redraw

.onpaint:
    locals
        ps PAINTSTRUCT
    endl
    lea     eax, [ps]
    invoke  BeginPaint, [hwnd], eax
    mov     ebx, eax
    
    ; Рисуем Блоки (Красные)
    invoke  CreateSolidBrush, 0x000000FF 
    invoke  SelectObject, ebx, eax
    push    eax
    
    xor     ecx, ecx
.drawBricks:
    cmp     [bricks + ecx], 1
    jne     .skipDraw
    push    ecx
    xor     edx, edx
    mov     eax, ecx
    mov     esi, BRICK_COLS
    div     esi
    imul    edx, BRICK_WIDTH + BRICK_GAP
    add     edx, 20
    imul    eax, BRICK_HEIGHT + BRICK_GAP
    add     eax, 20
    mov     edi, edx
    add     edi, BRICK_WIDTH
    mov     esi, eax
    add     esi, BRICK_HEIGHT
    invoke  Rectangle, ebx, edx, eax, edi, esi
    pop     ecx
.skipDraw:
    inc     ecx
    cmp     ecx, BRICK_ROWS * BRICK_COLS
    jl      .drawBricks
    
    pop     eax
    invoke  SelectObject, ebx, eax
    invoke  DeleteObject, eax

    ; Рисуем мяч (Синий)
    invoke  CreateSolidBrush, 0x00FF9000 
    invoke  SelectObject, ebx, eax
    push    eax
    mov     esi, [ballX]
    mov     edi, [ballY]
    mov     ecx, esi
    mov     edx, edi
    add     ecx, [ballSize]
    add     edx, [ballSize]
    invoke  Ellipse, ebx, esi, edi, ecx, edx
    pop     eax
    invoke  SelectObject, ebx, eax
    invoke  DeleteObject, eax

    ; Ракетка
    invoke  CreateSolidBrush, 0x00000000
    invoke  SelectObject, ebx, eax
    push    eax
    mov     esi, [padX]
    mov     edi, [padY]
    mov     ecx, esi
    add     ecx, [padW]
    mov     edx, edi
    add     edx, [padH]
    invoke  Rectangle, ebx, esi, edi, ecx, edx
    pop     eax
    invoke  SelectObject, ebx, eax
    invoke  DeleteObject, eax
    
    lea     eax, [ps]
    invoke  EndPaint, [hwnd], eax
    jmp     .finish

.wmdestroy:
    invoke  KillTimer, [hwnd], 1
    invoke  PostQuitMessage, 0
    xor     eax, eax

.finish:
    pop     edi esi ebx
    ret
endp

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL',\
            user32,   'USER32.DLL',\
            gdi32,    'GDI32.DLL'

    import kernel32, ExitProcess, 'ExitProcess', GetModuleHandle, 'GetModuleHandleA'
    import user32, RegisterClass, 'RegisterClassA', CreateWindowEx, 'CreateWindowExA',\
                   DefWindowProc, 'DefWindowProcA', GetMessage, 'GetMessageA',\
                   TranslateMessage, 'TranslateMessage', DispatchMessage, 'DispatchMessageA',\
                   PostQuitMessage, 'PostQuitMessage', SetTimer, 'SetTimer', KillTimer, 'KillTimer',\
                   InvalidateRect, 'InvalidateRect', BeginPaint, 'BeginPaint', EndPaint, 'EndPaint',\
                   GetClientRect, 'GetClientRect'
    import gdi32,  Ellipse, 'Ellipse', Rectangle, 'Rectangle', CreateSolidBrush, 'CreateSolidBrush', \
                   SelectObject, 'SelectObject', DeleteObject, 'DeleteObject'
