format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    _class      db 'ArkanoidClass',0
    _title      db 'FASM Arkanoid: Bricks Edition',0
    
    ; Мяч
    ballX       dd 200
    ballY       dd 150
    ballDX      dd 4
    ballDY      dd -4
    ballSize    dd 12

    ; Ракетка
    padX        dd 200
    padY        dd 260
    padW        dd 80
    padH        dd 12

    ; Блоки (5 колонок, 3 ряда = 15 штук)
    BRICK_W     = 80
    BRICK_H     = 20
    COL_COUNT   = 5
    ROW_COUNT   = 3
    ; Массив статусов блоков: 1 - жив, 0 - выбит
    bricks      db 1,1,1,1,1
                db 1,1,1,1,1
                db 1,1,1,1,1

    msg         MSG
    wc          WNDCLASS
    rect        RECT

section '.code' code readable executable
start:
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.lpszClassName], _class
    mov     [wc.hbrBackground], COLOR_WINDOW + 1
    invoke  RegisterClass, wc
    
    invoke  CreateWindowEx, 0, _class, _title, WS_VISIBLE + WS_SYSMENU,\
            100, 100, 460, 340, NULL, NULL, [wc.hInstance], NULL
    
    invoke  SetTimer, eax, 1, 16, NULL

msg_loop:
    invoke  GetMessage, msg, NULL, 0, 0
    or      eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    push    ebx esi edi
    
    cmp     [wmsg], WM_KEYDOWN
    je      .onkey
    cmp     [wmsg], WM_TIMER
    je      .ontimer
    cmp     [wmsg], WM_PAINT
    je      .onpaint
    cmp     [wmsg], WM_DESTROY
    je      .wmdestroy
    
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp     .finish

.onkey:
    mov     eax, [wparam]
    cmp     eax, VK_LEFT
    je      .moveLeft
    cmp     eax, VK_RIGHT
    je      .moveRight
    jmp     .finish
.moveLeft:
    sub     [padX], 25
    jmp     .finish
.moveRight:
    add     [padX], 25
    jmp     .finish

.ontimer:
    ; Движение мяча
    mov     eax, [ballDX]
    add     [ballX], eax
    mov     eax, [ballDY]
    add     [ballY], eax
    
    ; Стенки и потолок
    cmp     [ballX], 0
    jle     .revX
    cmp     [ballX], 430
    jge     .revX
    cmp     [ballY], 0
    jle     .revY
    cmp     [ballY], 300
    jge     .resetBall

    ; Проверка столкновения с ракеткой
    mov     eax, [ballY]
    add     eax, [ballSize]
    cmp     eax, [padY]
    jl      .checkBricks
    mov     ebx, [padY]
    add     ebx, [padH]
    cmp     eax, ebx
    jg      .checkBricks
    mov     eax, [ballX]
    cmp     eax, [padX]
    jl      .checkBricks
    mov     ebx, [padX]
    add     ebx, [padW]
    cmp     eax, ebx
    jg      .checkBricks
    neg     [ballDY]
    jmp     .redraw

.checkBricks:
    ; Логика столкновения с блоками
    xor     ecx, ecx ; Индекс ряда r
.row_loop:
    xor     edx, edx ; Индекс колонки c
.col_loop:
    ; Вычисляем индекс в массиве: ecx * COL_COUNT + edx
    mov     eax, ecx
    imul    eax, COL_COUNT
    add     eax, edx
    
    cmp     [bricks + eax], 0
    je      .next_col ; Блок уже выбит
    
    ; Координаты блока
    mov     ebx, edx
    imul    ebx, BRICK_W + 5 ; X блока
    add     ebx, 20
    mov     esi, ecx
    imul    esi, BRICK_H + 5 ; Y блока
    add     esi, 20
    
    ; Проверка попадания мяча в блок (AABB)
    mov     edi, [ballX]
    cmp     edi, ebx
    jl      .next_col
    add     ebx, BRICK_W
    cmp     edi, ebx
    jg      .next_col
    
    mov     edi, [ballY]
    cmp     edi, esi
    jl      .next_col
    add     esi, BRICK_H
    cmp     edi, esi
    jg      .next_col
    
    ; Попали!
    mov     [bricks + eax], 0 ; Удаляем блок
    neg     [ballDY]          ; Отскок
    jmp     .redraw

.next_col:
    inc     edx
    cmp     edx, COL_COUNT
    jl      .col_loop
    inc     ecx
    cmp     ecx, ROW_COUNT
    jl      .row_loop
    jmp     .redraw

.revX: neg [ballDX]
    jmp .redraw
.revY: neg [ballDY]
    jmp .redraw
.resetBall:
    mov [ballX], 200
    mov [ballY], 150
    mov [ballDY], -4

.redraw:
    invoke  InvalidateRect, [hwnd], NULL, TRUE
    jmp     .finish

.onpaint:
    locals
        ps PAINTSTRUCT
    endl
    lea     eax, [ps]
    invoke  BeginPaint, [hwnd], eax
    mov     ebx, eax
    
    ; Ракетка
    invoke  Rectangle, ebx, [padX], [padY], [padX], [padY] ; dummy
    mov     eax, [padX]
    mov     ecx, [padY]
    mov     edx, eax
    mov     esi, ecx
    add     edx, [padW]
    add     esi, [padH]
    invoke  Rectangle, ebx, eax, ecx, edx, esi

    ; Мяч
    mov     eax, [ballX]
    mov     ecx, [ballY]
    mov     edx, eax
    mov     esi, ecx
    add     edx, [ballSize]
    add     esi, [ballSize]
    invoke  Ellipse, ebx, eax, ecx, edx, esi

    ; Отрисовка кирпичей
    xor     ecx, ecx
.draw_row:
    xor     edx, edx
.draw_col:
    mov     eax, ecx
    imul    eax, COL_COUNT
    add     eax, edx
    cmp     [bricks + eax], 0
    je      .skip_draw
    
    push    ecx edx
    mov     esi, edx
    imul    esi, BRICK_W + 5
    add     esi, 20 ; X
    mov     edi, ecx
    imul    edi, BRICK_H + 5
    add     edi, 20 ; Y
    mov     eax, esi
    add     eax, BRICK_W
    mov     ebx, edi
    add     ebx, BRICK_H
    invoke  Rectangle, [ps.hdc], esi, edi, eax, ebx
    pop     edx ecx
.skip_draw:
    inc     edx
    cmp     edx, COL_COUNT
    jl      .draw_col
    inc     ecx
    cmp     ecx, ROW_COUNT
    jl      .draw_row

    lea     eax, [ps]
    invoke  EndPaint, [hwnd], eax
    jmp     .finish

.wmdestroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
.finish:
    pop     edi esi ebx
    ret
endp

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL', user32, 'USER32.DLL', gdi32, 'GDI32.DLL'
    import kernel32, ExitProcess, 'ExitProcess', GetModuleHandle, 'GetModuleHandleA'
    import user32, RegisterClass, 'RegisterClassA', CreateWindowEx, 'CreateWindowExA',\
                   DefWindowProc, 'DefWindowProcA', GetMessage, 'GetMessageA',\
                   TranslateMessage, 'TranslateMessage', DispatchMessage, 'DispatchMessageA',\
                   PostQuitMessage, 'PostQuitMessage', SetTimer, 'SetTimer', InvalidateRect, 'InvalidateRect',\
                   BeginPaint, 'BeginPaint', EndPaint, 'EndPaint'
    import gdi32,  Ellipse, 'Ellipse', Rectangle, 'Rectangle'
